package com.example.myprint // ЗАМЕНИ на свой package, если менял

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Layout
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Невидимая активность: «Печать» в меню выделенного текста -> сразу на принтер. */
class QuickPrintActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = when (intent?.action) {
            Intent.ACTION_PROCESS_TEXT -> intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            Intent.ACTION_SEND -> intent.getCharSequenceExtra(Intent.EXTRA_TEXT)
            else -> null
        }?.toString()
        if (text.isNullOrBlank()) { finish(); return }

        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val addr = prefs.getString("addr", null)
        val direct = prefs.getBoolean("direct", true)
        val permOk = Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        // Нет принтера / нет разрешения / режим «с редактором» -> открываем редактор
        if (!direct || addr == null || !permOk) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setAction(Intent.ACTION_SEND)
                    .putExtra(Intent.EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            finish()
            return
        }

        val size = prefs.getFloat("size", 28f)
        val dark = prefs.getFloat("dark", 0.5f)
        val bold = prefs.getBoolean("bold", false)
        val align = when (prefs.getInt("align", 0)) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val app = applicationContext
        val printer = CatPrinter.get(app)
        Toast.makeText(app, "Печатаю…", Toast.LENGTH_SHORT).show()

        scope.launch {
            try {
                if (!printer.isReady && !printer.connect(addr)) {
                    Toast.makeText(app, "Не удалось подключиться к принтеру (включён ли он?)", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val layout = makeLayout(text, size, bold, align)
                val energy = (0x1000 + dark * 0x3000).toInt()
                val speed = if (prefs.getInt("mode", 0) == 1) SPEED_QUALITY else SPEED_FAST
                withContext(Dispatchers.Default) { printer.print(renderRows(layout), energy, speed) }
                Toast.makeText(app, "Отправлено на принтер", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(app, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                // отключаемся, чтобы не разряжать принтер и планшет
                delay(1500)
                printer.close()
                finish()
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

package com.example.myprint // ЗАМЕНИ на свой package, если менял

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri

/** Загрузка фото с учётом поворота из EXIF и без лишнего расхода памяти. */
fun loadPhoto(ctx: Context, uri: Uri): Bitmap? {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    val longSide = maxOf(bounds.outWidth, bounds.outHeight)
    while (longSide / sample > 2400) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
    val orientation = try {
        cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }
    val m = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
    }
    if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    return bmp
}

/**
 * Фото -> чёрно-белая картинка шириной 384 точки (дизеринг Флойда–Стейнберга).
 * Если rotateLandscape, горизонтальное фото поворачивается, чтобы длинная сторона шла вдоль бумаги.
 */
fun prepareBitmap(src: Bitmap, rotateLandscape: Boolean, brightness: Float, contrast: Float): Bitmap {
    var b = src
    if (rotateLandscape && b.width > b.height) {
        val m = Matrix()
        m.postRotate(90f)
        b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    val w = PRINT_WIDTH
    val h = maxOf(1, (b.height.toLong() * w / b.width).toInt())
    val scaled = Bitmap.createScaledBitmap(b, w, h, true)
    val px = IntArray(w * h)
    scaled.getPixels(px, 0, w, 0, 0, w, h)

    val g = FloatArray(w * h)
    for (i in px.indices) {
        val c = px[i]
        val a = Color.alpha(c) / 255f
        var l = Color.red(c) * 0.299f + Color.green(c) * 0.587f + Color.blue(c) * 0.114f
        l = l * a + 255f * (1f - a)                       // прозрачное = белое
        l = (l - 128f) * contrast + 128f + brightness * 255f
        g[i] = l.coerceIn(0f, 255f)
    }
    for (y in 0 until h) {
        for (x in 0 until w) {
            val i = y * w + x
            val old = g[i]
            val nw = if (old < 128f) 0f else 255f
            val err = old - nw
            g[i] = nw
            if (x + 1 < w) g[i + 1] += err * 7f / 16f
            if (y + 1 < h) {
                if (x > 0) g[i + w - 1] += err * 3f / 16f
                g[i + w] += err * 5f / 16f
                if (x + 1 < w) g[i + w + 1] += err * 1f / 16f
            }
        }
    }
    for (i in px.indices) px[i] = if (g[i] < 128f) Color.BLACK else Color.WHITE
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

/** Чёрно-белая картинка -> строки по 48 байт для принтера. */
fun bitmapRows(bmp: Bitmap): Sequence<ByteArray> = sequence {
    val w = bmp.width
    val h = bmp.height
    val px = IntArray(w)
    for (y in 0 until h) {
        bmp.getPixels(px, 0, w, 0, y, w, 1)
        val line = ByteArray(PRINT_WIDTH / 8)
        for (x in 0 until minOf(w, PRINT_WIDTH)) {
            if (Color.red(px[x]) < 128) {
                line[x shr 3] = (line[x shr 3].toInt() or (1 shl (x and 7))).toByte()
            }
        }
        yield(line)
    }
}

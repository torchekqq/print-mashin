package com.example.myprint // ЗАМЕНИ на свой package, если менял

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/** Отдельное окно «Печать фото»: сюда приходят картинки через «Поделиться». */
class PhotoActivity : ComponentActivity() {
    private val incoming = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent { MaterialTheme { Surface { PhotoScreen(incoming) } } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val u = extraUri(i)
            if (u != null) incoming.value = u
        }
    }

    @Suppress("DEPRECATION")
    private fun extraUri(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra(Intent.EXTRA_STREAM)
}

@Composable
fun PhotoScreen(incoming: MutableState<Uri?>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    val printer = remember { CatPrinter.get(ctx) }

    var uri by remember { mutableStateOf<Uri?>(null) }
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var prepared by remember { mutableStateOf<Bitmap?>(null) }
    var rotate by remember { mutableStateOf(prefs.getBoolean("photo_rotate", true)) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var dark by remember { mutableFloatStateOf(prefs.getFloat("photo_dark", DEFAULT_DARK)) }
    var copies by remember { mutableIntStateOf(1) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val perms = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT) else arrayOf<String>()
    fun granted() = perms.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) uri = u
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        status = if (granted()) "Разрешение получено, нажми «Печатать» ещё раз" else "Нужно разрешение Bluetooth"
    }

    LaunchedEffect(incoming.value) {
        incoming.value?.let { uri = it; incoming.value = null }
    }

    LaunchedEffect(uri) {
        val u = uri ?: return@LaunchedEffect
        status = "Загружаю фото…"
        src = withContext(Dispatchers.IO) { runCatching { loadPhoto(ctx, u) }.getOrNull() }
        status = if (src == null) "Не удалось открыть фото" else ""
    }

    LaunchedEffect(src, rotate, brightness, contrast) {
        val s = src ?: return@LaunchedEffect
        delay(200)   // чтобы не пересчитывать на каждое движение ползунка
        prepared = withContext(Dispatchers.Default) { prepareBitmap(s, rotate, brightness, contrast) }
    }

    fun doPrint() {
        val a = prefs.getString("addr", null)
        if (a == null) { status = "Сначала выбери принтер в окне «Текст и принтер»"; return }
        val bmp = prepared ?: return
        if (!granted()) { permLauncher.launch(perms); return }
        scope.launch {
            busy = true
            try {
                if (!printer.isReady && !printer.connect(a)) {
                    status = "Не удалось подключиться"
                    return@launch
                }
                val energy = energyFromDark(dark)
                val speed = speedDivider(prefs.getFloat("lps", LPS_FAST))
                val compress = prefs.getBoolean("compress", true)
                for (i in 1..copies) {
                    status = if (copies > 1) "Копия $i из $copies…" else "Печать…"
                    withContext(Dispatchers.Default) {
                        printer.print(bitmapRows(bmp), energy, speed, true, compress)
                    }
                }
                status = ""
            } catch (e: Exception) {
                status = "Ошибка: ${e.message}"
                printer.close()
            } finally {
                busy = false
            }
        }
    }

    Box(Modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 640.dp).fillMaxSize().padding(16.dp)) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Выбрать фото") }
                    OutlinedButton(onClick = {
                        ctx.startActivity(Intent(ctx, MainActivity::class.java))
                    }) { Text("Текст и принтер") }
                }

                val p = prepared
                if (p != null) {
                    Text("На бумаге: ${p.width}×${p.height} точек, длина ≈ ${"%.1f".format(p.height / 80f)} см")
                    Box(
                        Modifier.fillMaxWidth().heightIn(max = 420.dp)
                            .background(Color.White)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Image(p.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    }
                } else if (uri == null) {
                    Text("Выбери фото или отправь его сюда через «Поделиться» → «Печать фото».")
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(rotate, { rotate = it; prefs.edit().putBoolean("photo_rotate", it).apply() })
                    Text("Горизонтальные фото поворачивать вдоль бумаги", Modifier.weight(1f))
                }

                Text("Яркость")
                Slider(brightness, { brightness = it }, valueRange = -0.5f..0.5f)
                Text("Контраст")
                Slider(contrast, { contrast = it }, valueRange = 0.5f..2f)
                Text("Темнота: ${(dark * 100).toInt()}%")
                Slider(dark, { dark = it; prefs.edit().putFloat("photo_dark", it).apply() })
            }

            Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (status.isNotEmpty()) Text(status)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Копий: $copies")
                    OutlinedButton(onClick = { if (copies > 1) copies-- }, enabled = !busy) { Text("−") }
                    OutlinedButton(onClick = { if (copies < 20) copies++ }, enabled = !busy) { Text("+") }
                }
                Button(
                    onClick = { doPrint() },
                    enabled = !busy && prepared != null,
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text(if (busy) "Печатаю…" else "Печатать фото") }
            }
        }
    }
}

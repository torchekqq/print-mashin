package com.example.myprint // ЗАМЕНИ на свой package

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.*
import java.util.UUID

const val PRINT_WIDTH = 384 // пикселей, 48 байт на строку

private val SERVICE = UUID.fromString("0000ae30-0000-1000-8000-00805f9b34fb")
private val WRITE_CHAR = UUID.fromString("0000ae01-0000-1000-8000-00805f9b34fb")

/** Раскладка текста под ширину принтера. Высота не ограничена. */
fun makeLayout(text: String, sizePx: Float, bold: Boolean, align: Layout.Alignment): StaticLayout {
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = sizePx
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }
    return StaticLayout.Builder.obtain(text, 0, text.length, paint, PRINT_WIDTH)
        .setAlignment(align)
        .setLineSpacing(0f, 1.1f)
        .build()
}

/** Рисуем полосами по 128 строк, чтобы не держать огромный Bitmap. Выдаём 48-байтные строки. */
fun renderRows(layout: StaticLayout): Sequence<ByteArray> = sequence {
    val band = 128
    val bmp = Bitmap.createBitmap(PRINT_WIDTH, band, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val px = IntArray(PRINT_WIDTH * band)
    var y = 0
    while (y < layout.height) {
        bmp.eraseColor(Color.WHITE)
        canvas.save()
        canvas.translate(0f, -y.toFloat())
        layout.draw(canvas)
        canvas.restore()
        bmp.getPixels(px, 0, PRINT_WIDTH, 0, 0, PRINT_WIDTH, band)
        for (r in 0 until band) {
            if (y + r >= layout.height) break
            val line = ByteArray(PRINT_WIDTH / 8)
            for (x in 0 until PRINT_WIDTH) {
                val c = px[r * PRINT_WIDTH + x]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (lum < 128) {
                    line[x shr 3] = (line[x shr 3].toInt() or (1 shl (x and 7))).toByte() // LSB first
                }
            }
            yield(line)
        }
        y += band
    }
}

/** Поиск BLE-устройств с именем. Возвращает функцию остановки. */
@SuppressLint("MissingPermission")
fun startScan(ctx: Context, onFound: (name: String, addr: String) -> Unit): () -> Unit {
    val scanner = ctx.getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
        ?: return {}
    val cb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val n = r.device.name ?: r.scanRecord?.deviceName ?: return
            onFound(n, r.device.address)
        }
    }
    scanner.startScan(cb)
    return { scanner.stopScan(cb) }
}

@SuppressLint("MissingPermission")
class CatPrinter(private val ctx: Context) {
    private var gatt: BluetoothGatt? = null
    private var ch: BluetoothGattCharacteristic? = null
    private var ready = CompletableDeferred<Boolean>()
    private var mtu = 23

    val isReady get() = ch != null

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.requestMtu(185)
            } else {
                ch = null
                ready.complete(false)
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = m
            g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            ch = g.getService(SERVICE)?.getCharacteristic(WRITE_CHAR)
            ready.complete(ch != null)
        }
    }

    suspend fun connect(address: String): Boolean {
        close()
        ready = CompletableDeferred()
        val dev = ctx.getSystemService(BluetoothManager::class.java).adapter.getRemoteDevice(address)
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        return withTimeoutOrNull(10_000) { ready.await() } ?: false
    }

    fun close() {
        gatt?.close()
        gatt = null
        ch = null
    }

    /** energy: 0x1000..0x4000, больше = темнее */
    suspend fun print(rows: Sequence<ByteArray>, energy: Int) {
        send(packet(0xA4, byteArrayOf(0x32)))                       // качество
        send(packet(0xA6, bytes(0xAA, 0x55, 0x17, 0x38, 0x44, 0x5F, 0x5F, 0x5F, 0x44, 0x38, 0x2C)))
        send(packet(0xAF, byteArrayOf((energy and 0xFF).toByte(), (energy shr 8).toByte())))
        send(packet(0xBE, byteArrayOf(0x01)))                       // применить энергию
        send(packet(0xBD, byteArrayOf(0x20)))                       // скорость
        for (row in rows) send(packet(0xA2, row))
        send(packet(0xA1, byteArrayOf(0x60, 0x00)))                 // протянуть бумагу
        send(packet(0xA6, bytes(0xAA, 0x55, 0x17, 0, 0, 0, 0, 0, 0, 0, 0x17)))
        send(packet(0xA3, byteArrayOf(0x00)))
        delay(500)
    }

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    private fun packet(cmd: Int, data: ByteArray): ByteArray {
        val out = ByteArray(8 + data.size)
        out[0] = 0x51
        out[1] = 0x78
        out[2] = cmd.toByte()
        out[3] = 0
        out[4] = (data.size and 0xFF).toByte()
        out[5] = (data.size shr 8).toByte()
        data.copyInto(out, 6)
        out[6 + data.size] = crc8(data)
        out[7 + data.size] = 0xAF.toByte()
        return out
    }

    private fun crc8(data: ByteArray): Byte {
        var crc = 0
        for (b in data) {
            crc = crc xor (b.toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 0x80) != 0) ((crc shl 1) xor 0x07) and 0xFF else (crc shl 1) and 0xFF
            }
        }
        return crc.toByte()
    }

    @Suppress("DEPRECATION")
    private suspend fun send(data: ByteArray) {
        val g = gatt ?: return
        val c = ch ?: return
        val size = (mtu - 3).coerceIn(20, 100)
        var i = 0
        while (i < data.size) {
            val part = data.copyOfRange(i, minOf(i + size, data.size))
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, part, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = part
                g.writeCharacteristic(c)
            }
            delay(10)
            i += size
        }
    }
}

package com.example.myprint // ЗАМЕНИ на свой package

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.*
import java.util.UUID

const val PRINT_WIDTH = 384 // пикселей, 48 байт на строку

private val SERVICE = UUID.fromString("0000ae30-0000-1000-8000-00805f9b34fb")
private val WRITE_CHAR = UUID.fromString("0000ae01-0000-1000-8000-00805f9b34fb")
private val NOTIFY_CHAR = UUID.fromString("0000ae02-0000-1000-8000-00805f9b34fb")
private val NOTIFY_CHAR2 = UUID.fromString("0000ae04-0000-1000-8000-00805f9b34fb")
private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

private fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

/** Раскладка текста под ширину принтера. Высота не ограничена. */
fun makeLayout(text: String, sizePx: Float, bold: Boolean, align: Layout.Alignment): StaticLayout {
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = sizePx
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }
    return StaticLayout.Builder.obtain(text, 0, text.length, paint, PRINT_WIDTH)
        .setAlignment(align)
        .setLineSpacing(0f, 1.1f)
        .build()
}

/** Рисуем полосами по 128 строк, чтобы не держать огромный Bitmap. Выдаём 48-байтные строки. */
fun renderRows(layout: StaticLayout): Sequence<ByteArray> = sequence {
    val band = 128
    val bmp = Bitmap.createBitmap(PRINT_WIDTH, band, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val px = IntArray(PRINT_WIDTH * band)
    var y = 0
    while (y < layout.height) {
        bmp.eraseColor(Color.WHITE)
        canvas.save()
        canvas.translate(0f, -y.toFloat())
        layout.draw(canvas)
        canvas.restore()
        bmp.getPixels(px, 0, PRINT_WIDTH, 0, 0, PRINT_WIDTH, band)
        for (r in 0 until band) {
            if (y + r >= layout.height) break
            val line = ByteArray(PRINT_WIDTH / 8)
            for (x in 0 until PRINT_WIDTH) {
                val c = px[r * PRINT_WIDTH + x]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (lum < 128) {
                    line[x shr 3] = (line[x shr 3].toInt() or (1 shl (x and 7))).toByte() // LSB first
                }
            }
            yield(line)
        }
        y += band
    }
}

/** Поиск BLE-устройств с именем. Возвращает функцию остановки. */
@SuppressLint("MissingPermission")
fun startScan(ctx: Context, onFound: (name: String, addr: String) -> Unit): () -> Unit {
    val scanner = ctx.getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
        ?: return {}
    val cb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val n = r.device.name ?: r.scanRecord?.deviceName ?: return
            onFound(n, r.device.address)
        }
    }
    scanner.startScan(cb)
    return { scanner.stopScan(cb) }
}

@SuppressLint("MissingPermission")
class CatPrinter(private val ctx: Context) {
    private var gatt: BluetoothGatt? = null
    private var ch: BluetoothGattCharacteristic? = null
    private var ready = CompletableDeferred<Boolean>()
    private var mtu = 23

    val isReady get() = ch != null

    var onLog: (String) -> Unit = {}

    private val pending = ArrayDeque<BluetoothGattCharacteristic>()

    private fun writeNextCccd(g: BluetoothGatt) {
        val n = pending.removeFirst()
        val d = n.getDescriptor(CCCD)
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
        } else {
            @Suppress("DEPRECATION")
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            @Suppress("DEPRECATION")
            g.writeDescriptor(d)
        }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            onLog("conn state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.requestMtu(185)
            } else {
                ch = null
                ready.complete(false)
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = m
            onLog("mtu=$mtu")
            g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            for (s in g.services) {
                onLog("S ${s.uuid.toString().take(8)}")
                for (c in s.characteristics) {
                    onLog("  C ${c.uuid.toString().take(8)} props=${c.properties}")
                }
            }
            val svc = g.getService(SERVICE)
            ch = svc?.getCharacteristic(WRITE_CHAR)
            pending.clear()
            for (u in listOf(NOTIFY_CHAR, NOTIFY_CHAR2)) {
                val n = svc?.getCharacteristic(u) ?: continue
                if (n.getDescriptor(CCCD) != null) {
                    g.setCharacteristicNotification(n, true)
                    pending.add(n)
                }
            }
            if (pending.isEmpty()) ready.complete(ch != null) else writeNextCccd(g)
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            onLog("notify ${d.characteristic.uuid.toString().take(8)} status=$status")
            if (pending.isEmpty()) ready.complete(ch != null) else writeNextCccd(g)
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            onLog("<- ${hex(value)}")
        }
        @Suppress("DEPRECATION")
        @Deprecated("old")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) onLog("<- ${hex(c.value ?: ByteArray(0))}")
        }
    }

    suspend fun connect(address: String): Boolean {
        close()
        ready = CompletableDeferred()
        val dev = ctx.getSystemService(BluetoothManager::class.java).adapter.getRemoteDevice(address)
        onLog("device: ${dev.name} ${dev.address}")
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        return withTimeoutOrNull(10_000) { ready.await() } ?: false
    }

    fun close() {
        gatt?.close()
        gatt = null
        ch = null
    }

    /** energy: 0x1000..0x4000, больше = темнее */
    suspend fun print(rows: Sequence<ByteArray>, energy: Int) {
        send(packet(0xA4, byteArrayOf(0x33)))                       // качество (как quality3 у Tiny Print)
        send(packet(0xAF, byteArrayOf((energy and 0xFF).toByte(), (energy shr 8).toByte())))
        send(packet(0xBE, byteArrayOf(0x01)))                       // режим «текст»
        send(packet(0xBD, byteArrayOf(0x20)))                       // скорость
        var n = 0
        for (row in rows) {
            send(packet(0xA2, row))
            if (++n % 200 == 0) send(packet(0xBD, byteArrayOf(0x20)))
        }
        send(packet(0xBD, byteArrayOf(0x19)))
        send(packet(0xA1, byteArrayOf(0x30, 0x00)))                 // протянуть бумагу
        send(packet(0xA1, byteArrayOf(0x30, 0x00)))
        send(packet(0xA3, byteArrayOf(0x00)))                       // запрос статуса
        onLog("sent $n rows")
        delay(1500)
    }

    /** Диагностика: шлём запрос статуса и смотрим ответы в логе */
    suspend fun probe() {
        onLog("-> A3 (status)")
        send(packet(0xA3, byteArrayOf(0x00)))
        delay(1500)
    }

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    private fun packet(cmd: Int, data: ByteArray): ByteArray {
        val out = ByteArray(8 + data.size)
        out[0] = 0x51
        out[1] = 0x78
        out[2] = cmd.toByte()
        out[3] = 0
        out[4] = (data.size and 0xFF).toByte()
        out[5] = (data.size shr 8).toByte()
        data.copyInto(out, 6)
        out[6 + data.size] = crc8(data)
        out[7 + data.size] = 0xFF.toByte()
        return out
    }

    private fun crc8(data: ByteArray): Byte {
        var crc = 0
        for (b in data) {
            crc = crc xor (b.toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 0x80) != 0) ((crc shl 1) xor 0x07) and 0xFF else (crc shl 1) and 0xFF
            }
        }
        return crc.toByte()
    }

    @Suppress("DEPRECATION")
    private suspend fun send(data: ByteArray) {
        val g = gatt ?: return
        val c = ch ?: return
        val size = (mtu - 3).coerceIn(20, 100)
        var i = 0
        while (i < data.size) {
            val part = data.copyOfRange(i, minOf(i + size, data.size))
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, part, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = part
                g.writeCharacteristic(c)
            }
            delay(10)
            i += size
        }
    }
}

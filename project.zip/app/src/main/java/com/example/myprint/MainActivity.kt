package com.example.myprint // ЗАМЕНИ на свой package

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Layout
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val incoming = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent { MaterialTheme { Surface { App(incoming) } } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val t = when (i?.action) {
            Intent.ACTION_PROCESS_TEXT -> i?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            Intent.ACTION_SEND -> i?.getCharSequenceExtra(Intent.EXTRA_TEXT)
            else -> null
        }?.toString()
        if (t != null) incoming.value = t
    }
}

@Composable
fun App(incoming: MutableState<String?>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var log by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current
    val printer = remember {
        CatPrinter(ctx.applicationContext).also { it.onLog = { s -> log = (log + s + "\n").takeLast(4000) } }
    }
    var name by remember { mutableStateOf(prefs.getString("name", null)) }

    var text by remember { mutableStateOf("") }
    var size by remember { mutableFloatStateOf(prefs.getFloat("size", 28f)) }
    var dark by remember { mutableFloatStateOf(prefs.getFloat("dark", 0.5f)) }
    var bold by remember { mutableStateOf(false) }
    var align by remember { mutableStateOf(Layout.Alignment.ALIGN_NORMAL) }
    var addr by remember { mutableStateOf(prefs.getString("addr", null)) }
    var status by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    // Текст из пункта «Печать» в меню выделения / «Поделиться»
    LaunchedEffect(incoming.value) {
        incoming.value?.let { text = it; incoming.value = null }
    }

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun granted() = perms.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { if (granted()) picker = true else status = "Нужно разрешение Bluetooth" }

    fun doPrint() {
        val a = addr ?: run { status = "Сначала выбери принтер"; return }
        if (text.isBlank()) return
        if (!granted()) { permLauncher.launch(perms); return }
        scope.launch {
            busy = true
            try {
                if (!printer.isReady && !printer.connect(a)) {
                    status = "Не удалось подключиться"
                    return@launch
                }
                status = "Печать…"
                val layout = makeLayout(text, size, bold, align)
                val energy = (0x1000 + dark * 0x3000).toInt()
                withContext(Dispatchers.Default) { printer.print(renderRows(layout), energy) }
                status = "Отправлено (смотри на принтер)"
            } catch (e: Exception) {
                status = "Ошибка: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    fun doDiag() {
        val a = addr ?: run { status = "Сначала выбери принтер"; return }
        if (!granted()) { permLauncher.launch(perms); return }
        scope.launch {
            busy = true
            try {
                log = ""
                if (!printer.isReady && !printer.connect(a)) {
                    status = "Не удалось подключиться"
                } else {
                    printer.probe()
                    status = "Диагностика готова"
                }
            } catch (e: Exception) {
                status = "Ошибка: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    // Центрируем и ограничиваем ширину: на планшете не растягивается на весь экран
    Box(
        Modifier.fillMaxSize().safeDrawingPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            Modifier.widthIn(max = 640.dp).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (addr != null) "Принтер: ${name ?: ""} $addr" else "Принтер не выбран",
                    Modifier.weight(1f)
                )
                OutlinedButton(onClick = {
                    if (granted()) picker = true else permLauncher.launch(perms)
                }) { Text("Выбрать") }
            }

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Текст") },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )

            Text("Размер шрифта: ${size.toInt()}")
            Slider(size, { size = it; prefs.edit().putFloat("size", it).apply() }, valueRange = 16f..64f)

            Text("Темнота: ${(dark * 100).toInt()}%")
            Slider(dark, { dark = it; prefs.edit().putFloat("dark", it).apply() })

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(bold, { bold = !bold }, { Text("Жирный") })
                FilterChip(align == Layout.Alignment.ALIGN_NORMAL,
                    { align = Layout.Alignment.ALIGN_NORMAL }, { Text("Слева") })
                FilterChip(align == Layout.Alignment.ALIGN_CENTER,
                    { align = Layout.Alignment.ALIGN_CENTER }, { Text("Центр") })
                FilterChip(align == Layout.Alignment.ALIGN_OPPOSITE,
                    { align = Layout.Alignment.ALIGN_OPPOSITE }, { Text("Справа") })
            }

            Button(
                onClick = { doPrint() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text(if (busy) "Печатаю…" else "Печатать") }

            if (status.isNotEmpty()) Text(status)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { doDiag() }, enabled = !busy) { Text("Диагностика") }
                if (log.isNotEmpty()) {
                    OutlinedButton(onClick = { clip.setText(AnnotatedString(log)) }) { Text("Копировать лог") }
                }
            }
            if (log.isNotEmpty()) {
                Text(
                    log,
                    Modifier.fillMaxWidth().heightIn(max = 160.dp).verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    if (picker) {
        val found = remember { mutableStateMapOf<String, String>() }
        DisposableEffect(Unit) {
            val stop = startScan(ctx) { n, a -> found[a] = n }
            onDispose { stop() }
        }
        AlertDialog(
            onDismissRequest = { picker = false },
            confirmButton = { TextButton({ picker = false }) { Text("Закрыть") } },
            title = { Text("Принтеры рядом") },
            text = {
                LazyColumn {
                    items(found.toList()) { (a, n) ->
                        Text(
                            "$n\n$a",
                            Modifier.fillMaxWidth().clickable {
                                addr = a
                                name = n
                                prefs.edit().putString("name", n).apply()
                                prefs.edit().putString("addr", a).apply()
                                printer.close()
                                picker = false
                            }.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        )
    }
}

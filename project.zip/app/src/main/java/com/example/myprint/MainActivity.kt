package com.example.myprint // ЗАМЕНИ на свой package

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Layout
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val incoming = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent { MaterialTheme { Surface { App(incoming) } } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val t = when (i?.action) {
            Intent.ACTION_PROCESS_TEXT -> i?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            Intent.ACTION_SEND -> i?.getCharSequenceExtra(Intent.EXTRA_TEXT)
            else -> null
        }?.toString()
        if (t != null) incoming.value = t
    }
}

@Composable
fun App(incoming: MutableState<String?>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    var log by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current
    val printer = remember {
        CatPrinter.get(ctx).also { it.onLog = { s -> log = (log + s + "\n").takeLast(4000) } }
    }
    var name by remember { mutableStateOf(prefs.getString("name", null)) }

    var text by remember { mutableStateOf("") }
    var size by remember { mutableFloatStateOf(prefs.getFloat("size", 28f)) }
    var dark by remember { mutableFloatStateOf(prefs.getFloat("dark", DEFAULT_DARK)) }
    var bold by remember { mutableStateOf(prefs.getBoolean("bold", false)) }
    var align by remember {
        mutableStateOf(
            when (prefs.getInt("align", 0)) {
                1 -> Layout.Alignment.ALIGN_CENTER
                2 -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
        )
    }
    var direct by remember { mutableStateOf(prefs.getBoolean("direct", true)) }
    var addr by remember { mutableStateOf(prefs.getString("addr", null)) }
    var status by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var copies by remember { mutableIntStateOf(1) }
    var quality by remember { mutableStateOf(prefs.getInt("mode", 0) == 1) }
    var speedLps by remember {
        mutableFloatStateOf(
            prefs.getFloat("lps", if (prefs.getInt("mode", 0) == 1) LPS_QUALITY else LPS_FAST)
        )
    }
    var compress by remember { mutableStateOf(prefs.getBoolean("compress", true)) }
    var showPreview by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    // Текст из пункта «Печать» в меню выделения / «Поделиться»
    LaunchedEffect(incoming.value) {
        incoming.value?.let { text = it; incoming.value = null }
    }

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun granted() = perms.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { if (granted()) picker = true else status = "Нужно разрешение Bluetooth" }

    fun doPrint() {
        val a = addr ?: run { status = "Сначала выбери принтер"; return }
        if (text.isBlank()) return
        if (!granted()) { permLauncher.launch(perms); return }
        scope.launch {
            busy = true
            try {
                if (!printer.isReady && !printer.connect(a)) {
                    status = "Не удалось подключиться"
                    return@launch
                }
                val layout = makeLayout(text, size, bold, align)
                val energy = energyFromDark(dark)
                val speed = speedDivider(speedLps)
                for (i in 1..copies) {
                    status = if (copies > 1) "Копия $i из $copies…" else "Печать…"
                    withContext(Dispatchers.Default) { printer.print(renderRows(layout), energy, speed, !quality, compress) }
                }
                status = "Отправлено (смотри на принтер)"
            } catch (e: Exception) {
                status = "Ошибка: ${e.message}"
                printer.close()
            } finally {
                busy = false
            }
        }
    }

    fun doDiag() {
        val a = addr ?: run { status = "Сначала выбери принтер"; return }
        if (!granted()) { permLauncher.launch(perms); return }
        scope.launch {
            busy = true
            try {
                log = ""
                if (!printer.isReady && !printer.connect(a)) {
                    status = "Не удалось подключиться"
                } else {
                    printer.probe()
                    status = "Диагностика готова"
                }
            } catch (e: Exception) {
                status = "Ошибка: ${e.message}"
            } finally {
                busy = false
            }
        }
    }

    // Центрируем и ограничиваем ширину: на планшете не растягивается на весь экран.
    // Сверху прокручиваемые настройки, снизу всегда видны копии и кнопки печати.
    Box(
        Modifier.fillMaxSize().safeDrawingPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(Modifier.widthIn(max = 640.dp).fillMaxSize().padding(16.dp)) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (addr != null) "Принтер: ${name ?: ""} $addr" else "Принтер не выбран",
                        Modifier.weight(1f)
                    )
                    OutlinedButton(onClick = {
                        if (granted()) picker = true else permLauncher.launch(perms)
                    }) { Text("Выбрать") }
                }

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Текст", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                    TextButton(onClick = { expanded = true }) { Text("Развернуть на весь экран") }
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )

                Text("Размер шрифта: ${size.toInt()}")
                Slider(size, { size = it; prefs.edit().putFloat("size", it).apply() }, valueRange = 16f..64f)

                Text("Темнота: ${(dark * 100).toInt()}%")
                Slider(dark, { dark = it; prefs.edit().putFloat("dark", it).apply() })

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!quality, { quality = false; speedLps = LPS_FAST; dark = darkFromEnergy(5000); prefs.edit().putInt("mode", 0).putFloat("lps", LPS_FAST).putFloat("dark", dark).apply() }, { Text("Быстрая печать") })
                    FilterChip(quality, { quality = true; speedLps = LPS_QUALITY; dark = darkFromEnergy(8000); prefs.edit().putInt("mode", 1).putFloat("lps", LPS_QUALITY).putFloat("dark", dark).apply() }, { Text("Качественная печать") })
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(bold, { bold = !bold; prefs.edit().putBoolean("bold", bold).apply() }, { Text("Жирный") })
                    FilterChip(align == Layout.Alignment.ALIGN_NORMAL,
                        { align = Layout.Alignment.ALIGN_NORMAL; prefs.edit().putInt("align", 0).apply() }, { Text("Слева") })
                    FilterChip(align == Layout.Alignment.ALIGN_CENTER,
                        { align = Layout.Alignment.ALIGN_CENTER; prefs.edit().putInt("align", 1).apply() }, { Text("Центр") })
                    FilterChip(align == Layout.Alignment.ALIGN_OPPOSITE,
                        { align = Layout.Alignment.ALIGN_OPPOSITE; prefs.edit().putInt("align", 2).apply() }, { Text("Справа") })
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(direct, { direct = it; prefs.edit().putBoolean("direct", it).apply() })
                    Text("«Печать» в меню текста печатает сразу, без редактора", Modifier.weight(1f))
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(compress, { compress = it; prefs.edit().putBoolean("compress", it).apply() })
                    Text("Сжатие данных (как в Tiny Print, быстрее)", Modifier.weight(1f))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { doDiag() }, enabled = !busy) { Text("Диагностика") }
                    if (log.isNotEmpty()) {
                        OutlinedButton(onClick = { clip.setText(AnnotatedString(log)) }) { Text("Копировать лог") }
                    }
                }
                if (log.isNotEmpty()) {
                    Text(
                        log,
                        Modifier.fillMaxWidth().heightIn(max = 160.dp).verticalScroll(rememberScrollState()),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            // Всегда видимая нижняя панель
            Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (status.isNotEmpty()) Text(status)

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Копий: $copies")
                    OutlinedButton(onClick = { if (copies > 1) copies-- }, enabled = !busy) { Text("−") }
                    OutlinedButton(onClick = { if (copies < 20) copies++ }, enabled = !busy) { Text("+") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showPreview = true },
                        modifier = Modifier.weight(1f).height(56.dp)
                    ) { Text("Предпросмотр") }
                    Button(
                        onClick = { doPrint() },
                        enabled = !busy,
                        modifier = Modifier.weight(2f).height(56.dp)
                    ) { Text(if (busy) "Печатаю…" else "Печатать") }
                }
            }
        }
    }

    if (picker) {
        val found = remember { mutableStateMapOf<String, String>() }
        DisposableEffect(Unit) {
            val stop = startScan(ctx) { n, a -> found[a] = n }
            onDispose { stop() }
        }
        AlertDialog(
            onDismissRequest = { picker = false },
            confirmButton = { TextButton({ picker = false }) { Text("Закрыть") } },
            title = { Text("Принтеры рядом") },
            text = {
                LazyColumn {
                    items(found.toList()) { (a, n) ->
                        Text(
                            "$n\n$a",
                            Modifier.fillMaxWidth().clickable {
                                addr = a
                                name = n
                                prefs.edit().putString("name", n).apply()
                                prefs.edit().putString("addr", a).apply()
                                printer.close()
                                picker = false
                            }.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        )
    }

    if (showPreview) {
        val layout = remember(text, size, bold, align) {
            makeLayout(text.ifBlank { " " }, size, bold, align)
        }
        val bmp = remember(layout) { renderPreview(layout).asImageBitmap() }
        val rows = layout.height
        AlertDialog(
            onDismissRequest = { showPreview = false },
            title = { Text("Предпросмотр") },
            text = {
                Column {
                    Text(
                        "Длина текста ≈ ${"%.1f".format(rows / 80f)} см (строк: ${layout.lineCount}). " +
                            "С отступом после печати ≈ ${"%.1f".format((rows + 96) / 80f)} см. Ширина бумаги 48 мм."
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.fillMaxWidth().heightIn(max = 380.dp)
                            .background(androidx.compose.ui.graphics.Color.White)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Image(bmp, null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPreview = false; doPrint() }, enabled = !busy) { Text("Печатать") }
            },
            dismissButton = { TextButton({ showPreview = false }) { Text("Закрыть") } }
        )
    }

    if (expanded) {
        Dialog(
            onDismissRequest = { expanded = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.safeDrawingPadding().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Редактор текста", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { expanded = false }) { Text("Готово") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    )
                }
            }
        }
    }
}

package com.example.myprint // ЗАМЕНИ на свой package

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

const val PRINT_WIDTH = 384 // пикселей, 48 байт на строку

// Скорость печати в строках в секунду. Команда BD принимает ДЕЛИТЕЛЬ: строк/с = 2304 / делитель
// (чем число меньше, тем печать быстрее; принтер держит делитель от 8 до 192).
const val LPS_FAST = 230f   // делитель 10 — так у Tiny Print для X5h
const val LPS_QUALITY = 115f
const val LPS_MIN = 36f
const val LPS_MAX = 288f
/** Энергия нагрева: ползунок 0..1 -> 2000..16000. У Tiny Print для X5h: «быстро» = 5000, текст = 8000. */
fun energyFromDark(d: Float): Int = (2000 + d * 14000).toInt()
fun darkFromEnergy(e: Int): Float = (e - 2000) / 14000f
val DEFAULT_DARK = darkFromEnergy(5000)
fun speedDivider(lps: Float): Int = (2304f / lps).toInt().coerceIn(8, 64)

private val SERVICE = UUID.fromString("0000ae30-0000-1000-8000-00805f9b34fb")
private val WRITE_CHAR = UUID.fromString("0000ae01-0000-1000-8000-00805f9b34fb")
private val SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
private val NOTIFY_CHAR = UUID.fromString("0000ae02-0000-1000-8000-00805f9b34fb")
private val NOTIFY_CHAR2 = UUID.fromString("0000ae04-0000-1000-8000-00805f9b34fb")
private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

private fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

/** Раскладка текста под ширину принтера. Высота не ограничена. */
fun makeLayout(text: String, sizePx: Float, bold: Boolean, align: Layout.Alignment): StaticLayout {
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = sizePx
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }
    return StaticLayout.Builder.obtain(text, 0, text.length, paint, PRINT_WIDTH)
        .setAlignment(align)
        .setLineSpacing(0f, 1.1f)
        .build()
}

/** Сжатие строки: подряд идущие одинаковые точки -> байт (цвет<<7 | длина<=127). null, если не выгодно. */
fun rleRow(raw: ByteArray): ByteArray? {
    val out = java.io.ByteArrayOutputStream()
    fun emit(bit: Int, count: Int) {
        var c = count
        while (c > 127) { out.write((bit shl 7) or 127); c -= 127 }
        if (c > 0) out.write((bit shl 7) or c)
    }
    var cur = raw[0].toInt() and 1
    var run = 0
    for (x in 0 until PRINT_WIDTH) {
        val bit = (raw[x shr 3].toInt() shr (x and 7)) and 1
        if (bit == cur) {
            run++
        } else {
            emit(cur, run)
            cur = bit
            run = 1
        }
    }
    emit(cur, run)
    return if (out.size() <= PRINT_WIDTH / 8) out.toByteArray() else null
}

/** Картинка для предпросмотра: как текст ляжет на бумагу (чёрно-белая, как при печати). */
fun renderPreview(layout: StaticLayout, maxH: Int = 6000): Bitmap {
    val h = minOf(layout.height, maxH).coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(PRINT_WIDTH, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.drawColor(Color.WHITE)
    layout.draw(canvas)
    val px = IntArray(PRINT_WIDTH * h)
    bmp.getPixels(px, 0, PRINT_WIDTH, 0, 0, PRINT_WIDTH, h)
    for (i in px.indices) {
        val c = px[i]
        val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        px[i] = if (lum < 128) Color.BLACK else Color.WHITE
    }
    bmp.setPixels(px, 0, PRINT_WIDTH, 0, 0, PRINT_WIDTH, h)
    return bmp
}

/** Рисуем полосами по 128 строк, чтобы не держать огромный Bitmap. Выдаём 48-байтные строки. */
fun renderRows(layout: StaticLayout): Sequence<ByteArray> = sequence {
    val band = 128
    val bmp = Bitmap.createBitmap(PRINT_WIDTH, band, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val px = IntArray(PRINT_WIDTH * band)
    var y = 0
    while (y < layout.height) {
        bmp.eraseColor(Color.WHITE)
        canvas.save()
        canvas.translate(0f, -y.toFloat())
        layout.draw(canvas)
        canvas.restore()
        bmp.getPixels(px, 0, PRINT_WIDTH, 0, 0, PRINT_WIDTH, band)
        for (r in 0 until band) {
            if (y + r >= layout.height) break
            val line = ByteArray(PRINT_WIDTH / 8)
            for (x in 0 until PRINT_WIDTH) {
                val c = px[r * PRINT_WIDTH + x]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (lum < 128) {
                    line[x shr 3] = (line[x shr 3].toInt() or (1 shl (x and 7))).toByte() // LSB first
                }
            }
            yield(line)
        }
        y += band
    }
}

/** Поиск BLE-устройств с именем. Возвращает функцию остановки. */
@SuppressLint("MissingPermission")
fun startScan(ctx: Context, onFound: (name: String, addr: String) -> Unit): () -> Unit {
    val scanner = ctx.getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner
        ?: return {}
    val cb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val n = r.device.name ?: r.scanRecord?.deviceName ?: return
            onFound(n, r.device.address)
        }
    }
    scanner.startScan(cb)
    return { scanner.stopScan(cb) }
}

@SuppressLint("MissingPermission")
class CatPrinter(private val ctx: Context) {
    companion object {
        @Volatile private var inst: CatPrinter? = null
        /** Один общий принтер на всё приложение (редактор и быстрая печать) */
        fun get(ctx: Context): CatPrinter =
            inst ?: synchronized(this) { inst ?: CatPrinter(ctx.applicationContext).also { inst = it } }
    }

    private var gatt: BluetoothGatt? = null
    private var ch: BluetoothGattCharacteristic? = null
    private var ready = CompletableDeferred<Boolean>()
    private var mtu = 23

    // ---- Классический Bluetooth (SPP), как у Tiny Print для X5h: быстрее и стабильнее, чем BLE ----
    private var sock: BluetoothSocket? = null
    private var sppOut: java.io.OutputStream? = null
    private var readerJob: Job? = null
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val isReady get() = ch != null || (sppOut != null && sock?.isConnected == true)

    private suspend fun trySpp(address: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val adapter = ctx.getSystemService(BluetoothManager::class.java).adapter
            val dev = adapter.getRemoteDevice(address)
            adapter.cancelDiscovery()
            var s: BluetoothSocket? = null
            try {
                s = dev.createRfcommSocketToServiceRecord(SPP_UUID)
                s.connect()
            } catch (e: Exception) {
                onLog("SPP (обычный): ${e.message}")
                try { s?.close() } catch (_: Exception) {}
                s = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(dev, 1) as BluetoothSocket
                s.connect()
            }
            sock = s
            sppOut = s!!.outputStream
            val ins = s.inputStream
            readerJob = ioScope.launch {
                val b = ByteArray(256)
                try {
                    while (true) {
                        val n = ins.read(b)
                        if (n < 0) break
                        if (n > 0) handleNotify(b.copyOf(n))
                    }
                } catch (_: Exception) {
                }
            }
            onLog("SPP: подключено (классический Bluetooth)")
            true
        } catch (e: Exception) {
            onLog("SPP не вышло: ${e.message}")
            closeSpp()
            false
        }
    }

    private fun closeSpp() {
        readerJob?.cancel()
        readerJob = null
        try { sppOut?.close() } catch (_: Exception) {}
        try { sock?.close() } catch (_: Exception) {}
        sppOut = null
        sock = null
    }

    var onLog: (String) -> Unit = {}

    /** Принтер шлёт 51 78 AE 01 01 00 10 70 FF («буфер полон») и ...00 00 FF («буфер пуст») */
    @Volatile private var paused = false
    @Volatile private var pauseEvents = 0

    private fun handleNotify(v: ByteArray) {
        var i = 0
        var isFlow = false
        while (i + 6 < v.size) {
            if (v[i] == 0x51.toByte() && v[i + 1] == 0x78.toByte() && v[i + 2] == 0xAE.toByte()) {
                val nowPaused = v[i + 6] == 0x10.toByte()
                if (nowPaused && !paused) pauseEvents++
                paused = nowPaused
                isFlow = true
            }
            i++
        }
        if (!isFlow) onLog("<- ${hex(v)}")
    }

    private suspend fun waitWhilePaused() {
        var t = 0
        while (paused && t < 3000) { delay(10); t++ }   // максимум ~30 с
        if (paused) paused = false
    }

    private val pending = ArrayDeque<BluetoothGattCharacteristic>()

    private fun writeNextCccd(g: BluetoothGatt) {
        val n = pending.removeFirst()
        val d = n.getDescriptor(CCCD)
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
        } else {
            @Suppress("DEPRECATION")
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            @Suppress("DEPRECATION")
            g.writeDescriptor(d)
        }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            onLog("conn state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                g.requestMtu(185)
            } else {
                ch = null
                ready.complete(false)
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = m
            onLog("mtu=$mtu")
            g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            for (s in g.services) {
                onLog("S ${s.uuid.toString().take(8)}")
                for (c in s.characteristics) {
                    onLog("  C ${c.uuid.toString().take(8)} props=${c.properties}")
                }
            }
            val svc = g.getService(SERVICE)
            ch = svc?.getCharacteristic(WRITE_CHAR)
            pending.clear()
            for (u in listOf(NOTIFY_CHAR, NOTIFY_CHAR2)) {
                val n = svc?.getCharacteristic(u) ?: continue
                if (n.getDescriptor(CCCD) != null) {
                    g.setCharacteristicNotification(n, true)
                    pending.add(n)
                }
            }
            if (pending.isEmpty()) ready.complete(ch != null) else writeNextCccd(g)
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            onLog("notify ${d.characteristic.uuid.toString().take(8)} status=$status")
            if (pending.isEmpty()) ready.complete(ch != null) else writeNextCccd(g)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            wd?.complete(Unit)
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            handleNotify(value)
        }
        @Suppress("DEPRECATION")
        @Deprecated("old")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) handleNotify(c.value ?: ByteArray(0))
        }
    }

    suspend fun connect(address: String): Boolean {
        close()
        onLog("device: $address")
        if (trySpp(address)) return true
        onLog("Пробую Bluetooth LE")
        ready = CompletableDeferred()
        val dev = ctx.getSystemService(BluetoothManager::class.java).adapter.getRemoteDevice(address)
        onLog("device: ${dev.name} ${dev.address}")
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        return withTimeoutOrNull(10_000) { ready.await() } ?: false
    }

    fun close() {
        closeSpp()
        gatt?.close()
        gatt = null
        ch = null
    }

    /** energy: 0x1000..0x4000, больше = темнее */
    private val lock = Mutex()

    /** imageMode=false: режим «текст» (быстрее), true: режим «картинка» (медленнее, плавнее) */
    suspend fun print(rows: Sequence<ByteArray>, energy: Int, speed: Int = speedDivider(LPS_FAST), imageMode: Boolean = false, compress: Boolean = true) =
        lock.withLock { printInternal(rows, energy, speed, imageMode, compress) }

    private suspend fun printInternal(rows: Sequence<ByteArray>, energy: Int, speed: Int, imageMode: Boolean, compress: Boolean) {
        paused = false
        pauseEvents = 0
        val t0 = System.currentTimeMillis()
        queue(packet(0xA4, byteArrayOf(0x33)))                       // качество (как quality3 у Tiny Print)
        queue(packet(0xAF, byteArrayOf((energy and 0xFF).toByte(), (energy shr 8).toByte())))
        queue(packet(0xBE, byteArrayOf(if (imageMode) 0x00 else 0x01)))   // режим: 1 = текст, 0 = картинка
        queue(packet(0xBD, byteArrayOf(speed.toByte())))             // скорость
        var n = 0
        for (row in rows) {
            val z = if (compress) rleRow(row) else null
            if (z != null) queue(packet(0xBF, z)) else queue(packet(0xA2, row))
            if (++n % 200 == 0) queue(packet(0xBD, byteArrayOf(speed.toByte())))
        }
        queue(packet(0xBD, byteArrayOf(0x19)))
        queue(packet(0xA1, byteArrayOf(0x30, 0x00)))                 // протянуть бумагу
        queue(packet(0xA1, byteArrayOf(0x30, 0x00)))
        queue(packet(0xA3, byteArrayOf(0x00)))                       // запрос статуса
        flush()
        onLog("sent $n rows in ${System.currentTimeMillis() - t0} ms, printer buffer full ${pauseEvents} times")
        delay(1500)
    }

    /** Диагностика: шлём запрос статуса и смотрим ответы в логе */
    suspend fun probe() {
        onLog("-> A3 (status)")
        send(packet(0xA3, byteArrayOf(0x00)))
        delay(1500)
    }

    private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    private fun packet(cmd: Int, data: ByteArray): ByteArray {
        val out = ByteArray(8 + data.size)
        out[0] = 0x51
        out[1] = 0x78
        out[2] = cmd.toByte()
        out[3] = 0
        out[4] = (data.size and 0xFF).toByte()
        out[5] = (data.size shr 8).toByte()
        data.copyInto(out, 6)
        out[6 + data.size] = crc8(data)
        out[7 + data.size] = 0xFF.toByte()
        return out
    }

    private fun crc8(data: ByteArray): Byte {
        var crc = 0
        for (b in data) {
            crc = crc xor (b.toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 0x80) != 0) ((crc shl 1) xor 0x07) and 0xFF else (crc shl 1) and 0xFF
            }
        }
        return crc.toByte()
    }

    // ---- Потоковая отправка: пакеты склеиваются в куски по размеру MTU, чтобы принтер не «голодал» ----
    private val buf = java.io.ByteArrayOutputStream()
    @Volatile private var wd: CompletableDeferred<Unit>? = null
    private var useCallback = true
    private var timeouts = 0

    private suspend fun queue(data: ByteArray) {
        buf.write(data)
        val size = if (sppOut != null) 180 else (mtu - 3).coerceIn(20, 180)
        while (buf.size() >= size) {
            val all = buf.toByteArray()
            buf.reset()
            buf.write(all, size, all.size - size)
            writeRaw(all.copyOfRange(0, size))
        }
    }

    private suspend fun flush() {
        val all = buf.toByteArray()
        buf.reset()
        if (all.isNotEmpty()) writeRaw(all)
    }

    private suspend fun send(data: ByteArray) {
        queue(data)
        flush()
    }

    @Suppress("DEPRECATION")
    private suspend fun writeRaw(part: ByteArray) {
        val o = sppOut
        if (o != null) {
            waitWhilePaused()
            withContext(Dispatchers.IO) {
                o.write(part)
                o.flush()
            }
            delay(4)   // пауза между пакетами, как у Tiny Print для X5h
            return
        }
        val g = gatt ?: return
        val c = ch ?: return
        waitWhilePaused()
        repeat(60) {
            val d = CompletableDeferred<Unit>()
            wd = d
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, part, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) ==
                    BluetoothStatusCodes.SUCCESS
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = part
                g.writeCharacteristic(c)
            }
            if (ok) {
                if (useCallback) {
                    val done = withTimeoutOrNull(100) { d.await() }
                    if (done == null && ++timeouts >= 3) useCallback = false   // callback не приходит -> пауза по таймеру
                } else {
                    delay(6)
                }
                return
            }
            delay(4)   // стек занят, пробуем ещё раз
        }
    }
}

// ======================= КАРТИНКИ =======================

/** Загрузка картинки из Uri: с уменьшением до разумного размера и поворотом по EXIF. Прозрачность -> белый фон. */
fun loadBitmap(ctx: Context, uri: android.net.Uri, maxSide: Int = 2400): Bitmap? {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

    val deg = try {
        cr.openInputStream(uri)?.use {
            when (android.media.ExifInterface(it).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (_: Exception) { 0 }

    val m = Matrix().apply { if (deg != 0) postRotate(deg.toFloat()) }
    val rotated = if (deg != 0) Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true) else raw
    // сводим к ARGB на белом фоне (убираем альфу)
    val flat = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
    Canvas(flat).apply { drawColor(Color.WHITE); drawBitmap(rotated, 0f, 0f, null) }
    return flat
}

/**
 * Готовит картинку к печати: ширина ровно 384, чёрно-белая.
 * photo=true  -> растр (Floyd–Steinberg) + лёгкая резкость: фото, градиенты.
 * photo=false -> чёткий порог: рисунки, логотипы, текст, QR-коды.
 * brightness: -0.5..0.5 (больше = светлее). rotate: 0/90/180/270.
 */
fun prepareImage(src: Bitmap, photo: Boolean, brightness: Float, rotate: Int): Bitmap {
    var bmp = src
    if (rotate != 0) {
        val m = Matrix().apply { postRotate(rotate.toFloat()) }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
    // уменьшение без лишнего размытия: сначала сжимаем, пока не близко к цели, потом один проход
    val h = maxOf(1, Math.round(bmp.height * PRINT_WIDTH / bmp.width.toFloat()))
    if (bmp.width != PRINT_WIDTH) {
        if (bmp.width >= PRINT_WIDTH * 2) {
            bmp = Bitmap.createScaledBitmap(bmp, PRINT_WIDTH * 2, maxOf(1, h * 2), true)
        }
        bmp = Bitmap.createScaledBitmap(bmp, PRINT_WIDTH, h, true)
    }

    val w = PRINT_WIDTH
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    var g = FloatArray(w * h) {
        val c = px[it]
        Color.red(c) * 0.299f + Color.green(c) * 0.587f + Color.blue(c) * 0.114f
    }

    // авто-контраст: растягиваем гистограмму между 1% и 99%
    val hist = IntArray(256)
    for (v in g) hist[v.toInt().coerceIn(0, 255)]++
    val total = g.size
    var acc = 0; var lo = 0; var hi = 255
    for (i in 0..255) { acc += hist[i]; if (acc >= total * 0.01) { lo = i; break } }
    acc = 0
    for (i in 255 downTo 0) { acc += hist[i]; if (acc >= total * 0.01) { hi = i; break } }
    if (hi - lo < 16) { lo = 0; hi = 255 }
    val scale = 255f / (hi - lo)
    val shift = brightness * 255f
    for (i in g.indices) g[i] = ((g[i] - lo) * scale + shift).coerceIn(0f, 255f)

    if (photo) {
        // лёгкая резкость (unsharp 3x3): на термопечати контуры иначе «плывут»
        val s = FloatArray(g.size)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (x == 0 || y == 0 || x == w - 1 || y == h - 1) { s[i] = g[i]; continue }
            val blur = (g[i - 1] + g[i + 1] + g[i - w] + g[i + w] + g[i] * 4f) / 8f
            s[i] = (g[i] + (g[i] - blur) * 0.8f).coerceIn(0f, 255f)
        }
        g = s
        // Floyd–Steinberg, змейкой
        for (y in 0 until h) {
            val ltr = y % 2 == 0
            var x = if (ltr) 0 else w - 1
            while (x in 0 until w) {
                val i = y * w + x
                val old = g[i]
                val nw = if (old < 128f) 0f else 255f
                g[i] = nw
                val err = old - nw
                val dx = if (ltr) 1 else -1
                if (x + dx in 0 until w) g[i + dx] += err * 7f / 16f
                if (y + 1 < h) {
                    if (x - dx in 0 until w) g[i + w - dx] += err * 3f / 16f
                    g[i + w] += err * 5f / 16f
                    if (x + dx in 0 until w) g[i + w + dx] += err * 1f / 16f
                }
                x += dx
            }
        }
    } else {
        // Текст и рисунки: адаптивный порог по локальному среднему (окно 15x15).
        // Тонкие штрихи и мелкий текст на сером фоне не пропадают, как при одном общем пороге.
        val r = 7
        val integ = DoubleArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0.0
            for (x in 0 until w) {
                rowSum += g[y * w + x]
                integ[(y + 1) * (w + 1) + (x + 1)] = integ[y * (w + 1) + (x + 1)] + rowSum
            }
        }
        val src = g.copyOf()
        for (y in 0 until h) {
            val y0 = maxOf(0, y - r); val y1 = minOf(h - 1, y + r)
            for (x in 0 until w) {
                val x0 = maxOf(0, x - r); val x1 = minOf(w - 1, x + r)
                val sum = integ[(y1 + 1) * (w + 1) + (x1 + 1)] - integ[y0 * (w + 1) + (x1 + 1)] -
                    integ[(y1 + 1) * (w + 1) + x0] + integ[y0 * (w + 1) + x0]
                val area = (x1 - x0 + 1) * (y1 - y0 + 1)
                val mean = (sum / area).toFloat()
                g[y * w + x] = if (src[y * w + x] < mean - 8f) 0f else 255f
            }
        }
    }

    for (i in px.indices) px[i] = if (g[i] < 128f) Color.BLACK else Color.WHITE
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(px, 0, w, 0, 0, w, h)
    return out
}

/** Строки по 48 байт из уже подготовленной ч/б картинки шириной 384 */
fun bitmapRows(bmp: Bitmap): Sequence<ByteArray> = sequence {
    val w = PRINT_WIDTH
    val px = IntArray(w)
    for (y in 0 until bmp.height) {
        bmp.getPixels(px, 0, w, 0, y, w, 1)
        val line = ByteArray(w / 8)
        for (x in 0 until w) {
            if (Color.red(px[x]) < 128) line[x shr 3] = (line[x shr 3].toInt() or (1 shl (x and 7))).toByte()
        }
        yield(line)
    }
}
